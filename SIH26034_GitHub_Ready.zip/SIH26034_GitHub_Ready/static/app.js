
const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const cameraBtn = document.getElementById("cameraBtn");
const snapBtn = document.getElementById("snapBtn");
const fileInput = document.getElementById("fileInput");
const previewBox = document.getElementById("previewBox");
const previewImage = document.getElementById("previewImage");
const removeBtn = document.getElementById("removeBtn");
const scanBtn = document.getElementById("scanBtn");
const cameraStatus = document.getElementById("cameraStatus");
const loading = document.getElementById("loading");
const errorBox = document.getElementById("error");
const emptyState = document.getElementById("emptyState");
const results = document.getElementById("results");
let stream = null;
let selectedFile = null;

function setFile(file){
  selectedFile=file;
  if(file){
    previewImage.src=URL.createObjectURL(file);
    previewBox.hidden=false;
    scanBtn.disabled=false;
  }
}
cameraBtn.onclick = async ()=>{
  if(stream){ stream.getTracks().forEach(t=>t.stop()); stream=null; cameraBtn.textContent="Open Camera"; snapBtn.disabled=true; cameraStatus.textContent="Camera stopped"; return; }
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1280},height:{ideal:720}},audio:false});
    video.srcObject=stream; snapBtn.disabled=false; cameraBtn.textContent="Close Camera"; cameraStatus.textContent="Camera ready";
  }catch(e){
    showError("Camera access was blocked. Allow camera permission in the browser, or use Upload Image.");
  }
};
snapBtn.onclick=()=>{
  if(!stream) return;
  canvas.width=video.videoWidth; canvas.height=video.videoHeight;
  canvas.getContext("2d").drawImage(video,0,0);
  canvas.toBlob(blob=>setFile(new File([blob],"camera_capture.jpg",{type:"image/jpeg"})),"image/jpeg",0.94);
};
fileInput.onchange=e=>{ if(e.target.files[0]) setFile(e.target.files[0]); };
removeBtn.onclick=()=>{
  selectedFile=null; fileInput.value=""; previewBox.hidden=true; scanBtn.disabled=true;
};
function showError(msg){errorBox.textContent=msg;errorBox.hidden=false;}
function clearError(){errorBox.hidden=true;}
scanBtn.onclick=async()=>{
  if(!selectedFile)return;
  clearError(); loading.hidden=false; scanBtn.disabled=true;
  const fd=new FormData();
  fd.append("image",selectedFile);
  fd.append("product_type",document.getElementById("productType").value);
  fd.append("imported",document.getElementById("imported").checked?"true":"false");
  try{
    const res=await fetch("/api/check",{method:"POST",body:fd});
    const data=await res.json();
    if(!res.ok) throw new Error(data.error||"Analysis failed");
    renderResults(data);
  }catch(e){showError(e.message);}
  finally{loading.hidden=true;scanBtn.disabled=false;}
};
function esc(s){return String(s??"—").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));}
function renderResults(d){
  emptyState.hidden=true; results.hidden=false;
  const sm=d.summary;
  const cls=sm.fails?"fail":(sm.reviews?"review":"pass");
  document.getElementById("summary").className="summary "+cls;
  document.getElementById("summary").innerHTML=`<div class="status">${esc(sm.status)}</div><div class="counts">${sm.passes} passed • ${sm.fails} failed • ${sm.reviews} need review</div>`;
  const f=d.fields;
  const fieldMap=[
    ["MRP",f.mrp],["Net quantity",f.net_quantity],["Manufacturer",f.manufacturer],
    ["Consumer care",f.consumer_care],["Email",f.email],["Generic name",f.generic_name],
    ["Best before",f.best_before],["Unit sale price",f.unit_sale_price]
  ];
  document.getElementById("fields").innerHTML=fieldMap.map(x=>`<div class="field"><label>${esc(x[0])}</label><b>${esc(x[1]||"Not detected")}</b></div>`).join("");
  document.getElementById("checks").innerHTML=d.results.map(r=>`
    <div class="check-card">
      <div class="check-top"><div class="check-name">${esc(r.label)}</div><span class="pill ${esc(r.status)}">${esc(r.status.replaceAll("_"," "))}</span></div>
      ${r.value?`<div class="value"><b>Detected:</b> ${esc(r.value)}</div>`:""}
      <div class="reason">${esc(r.reason)}</div>
    </div>`).join("");
  document.getElementById("ocrText").textContent=d.extracted_text||"";
  document.getElementById("pdfBtn").href=d.report_url;
}
